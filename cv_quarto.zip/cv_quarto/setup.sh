#!/bin/bash
# ==============================================================================
# Setup inicial do projeto de CV
# ==============================================================================

set -e

echo "🔧 Configurando projeto de CV..."

# 1. Baixar CSL para formatação de citações
echo "📚 Baixando estilo de citação APA..."
curl -sL "https://raw.githubusercontent.com/citation-style-language/styles/master/apa.csl" -o apa.csl

# Opcional: ABNT para português
# curl -sL "https://raw.githubusercontent.com/citation-style-language/styles/master/associacao-brasileira-de-normas-tecnicas.csl" -o abnt.csl

# 2. Instalar pacotes R
echo "📦 Instalando pacotes R..."
Rscript -e 'install.packages(c("dplyr", "knitr", "glue", "scholar", "RefManageR"), repos="https://cloud.r-project.org")'

# 3. Verificar Quarto
echo "🔍 Verificando Quarto..."
if command -v quarto &> /dev/null; then
    echo "✓ Quarto instalado: $(quarto --version)"
else
    echo "⚠️  Quarto não encontrado. Instale em: https://quarto.org/docs/get-started/"
    exit 1
fi

# 4. Criar diretório de output
mkdir -p _site

echo ""
echo "✅ Setup completo!"
echo ""
echo "Próximos passos:"
echo "  1. Edite seu Google Scholar ID em fetch_publications.R"
echo "  2. Execute: Rscript -e \"source('fetch_publications.R'); fetch_all_publications(source='scholar')\""
echo "  3. Renderize: quarto render cv_leonardo_nascimento.qmd"
echo "  4. Abra _site/cv_leonardo_nascimento.html no navegador"
